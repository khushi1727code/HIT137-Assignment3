import pygame
from player import Player
from enemy import Enemy
from boss import BossEnemy
from projectile import Projectile
from collectible import Collectible
from level import Level

# Init
pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Human vs Human")
clock = pygame.time.Clock()
FPS = 60

# Font
font = pygame.font.SysFont(None, 24)
big_font = pygame.font.SysFont(None, 72)

# Game variables
level_number = 1
current_level = Level(level_number)
player = Player(100, 500)
player_group = pygame.sprite.Group(player)
enemies = pygame.sprite.Group(*current_level.enemies)
collectibles = pygame.sprite.Group(*current_level.collectibles)
projectiles = pygame.sprite.Group()
enemy_projectiles = pygame.sprite.Group()

score = 0
game_over = False
game_won = False
restart_prompt = False

def draw_health_bar(entity, surface):
    bar_width, bar_height = 40, 6
    x = entity.rect.centerx - bar_width // 2
    y = entity.rect.top - 10
    fill = int((entity.health / entity.max_health) * bar_width)
    pygame.draw.rect(surface, (255, 0, 0), (x, y, bar_width, bar_height))
    pygame.draw.rect(surface, (0, 255, 0), (x, y, fill, bar_height))

def reset_game():
    global level_number, player, player_group, enemies, collectibles, projectiles, enemy_projectiles
    global score, game_over, game_won, restart_prompt, current_level

    level_number = 1
    current_level = Level(level_number)
    player = Player(100, 500)
    player_group = pygame.sprite.Group(player)
    enemies = pygame.sprite.Group(*current_level.enemies)
    collectibles = pygame.sprite.Group(*current_level.collectibles)
    projectiles = pygame.sprite.Group()
    enemy_projectiles = pygame.sprite.Group()

    score = 0
    game_over = False
    game_won = False
    restart_prompt = False

# Main loop
running = True
while running:
    clock.tick(FPS)
    keys = pygame.key.get_pressed()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if game_over and event.type == pygame.KEYDOWN and event.key == pygame.K_r:
            reset_game()

        if not game_over and event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                player.jump()
            if event.key == pygame.K_f:
                projectile = Projectile(player.rect.centerx, player.rect.centery, 1)
                projectiles.add(projectile)

    if game_over:
        screen.fill((0, 0, 0))
        msg = big_font.render("🎉 You Won!" if game_won else "💀 Game Over!", True, (255, 255, 0) if game_won else (255, 0, 0))
        screen.blit(msg, (WIDTH // 2 - msg.get_width() // 2, HEIGHT // 2 - 50))
        restart = font.render("Press R to Restart", True, (255, 255, 255))
        screen.blit(restart, (WIDTH // 2 - restart.get_width() // 2, HEIGHT // 2 + 30))
        pygame.display.flip()
        continue

    player_group.update(keys)
    enemies.update()
    projectiles.update()
    enemy_projectiles.update()

    if player.rect.bottom >= HEIGHT:
        player.rect.bottom = HEIGHT
        player.on_ground = True
        player.velocity_y = 0
    else:
        player.on_ground = False

    # Wall collision
    if player.rect.left <= 0:
        player.rect.left = 0
    if player.rect.right >= WIDTH:
        player.rect.right = WIDTH

    # Boss minion/projectile
    for enemy in enemies:
        if isinstance(enemy, BossEnemy):
            proj = enemy.shoot()
            if proj:
                enemy_projectiles.add(proj)
            minion = enemy.spawn_minion()
            if minion:
                enemies.add(minion)

    # Enemy hits player
    for enemy in pygame.sprite.spritecollide(player, enemies, False):
        player.health -= 0.5
        if player.health <= 0:
            player.lives -= 1
            if player.lives <= 0:
                game_over = True
            else:
                player.health = 100
                player.rect.topleft = (100, 500)

    # Enemy projectile hits player
    for ep in pygame.sprite.spritecollide(player, enemy_projectiles, True):
        player.health -= 10
        if player.health <= 0:
            player.lives -= 1
            if player.lives <= 0:
                game_over = True
            else:
                player.health = 100
                player.rect.topleft = (100, 500)

    # Player projectile hits enemy
    for p in projectiles:
        for enemy in pygame.sprite.spritecollide(p, enemies, False):
            enemy.take_damage(25)
            if enemy.health <= 0:
                if isinstance(enemy, BossEnemy):
                    score += 100
                else:
                    score += 20
                enemies.remove(enemy)
            p.kill()

    # Collectibles
    for c in pygame.sprite.spritecollide(player, collectibles, True):
        if c.type == "coin":
            score += 10
        elif c.type == "health":
            player.health = min(player.health + 30, 100)
        elif c.type == "life":
            player.lives += 1

    # Level progression
    if not any(isinstance(e, Enemy) or isinstance(e, BossEnemy) for e in enemies):
        level_number += 1
        if level_number > 3:
            game_won = True
            game_over = True
        else:
            current_level = Level(level_number)
            enemies = pygame.sprite.Group(*current_level.enemies)
            collectibles = pygame.sprite.Group(*current_level.collectibles)
            player.rect.topleft = (100, 500)
            player.health = 100

    # Draw
    screen.fill((30, 30, 30))
    player_group.draw(screen)
    enemies.draw(screen)
    projectiles.draw(screen)
    enemy_projectiles.draw(screen)
    collectibles.draw(screen)

    for enemy in enemies:
        draw_health_bar(enemy, screen)
    draw_health_bar(player, screen)

    stats = font.render(f"Level: {level_number}  Health: {int(player.health)}  Lives: {player.lives}  Score: {score}", True, (255, 255, 255))
    screen.blit(stats, (10, 10))
    pygame.display.flip()

pygame.quit()