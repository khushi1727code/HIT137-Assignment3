import pygame

class Collectible(pygame.sprite.Sprite):
    def __init__(self, x, y, ctype):
        super().__init__()
        self.type = ctype
        self.image = pygame.Surface((30, 30), pygame.SRCALPHA)  # Transparent surface

        if ctype == "coin":
            self.image.fill((0, 0, 0, 0))  # Transparent background
            pygame.draw.circle(self.image, (255, 215, 0), (15, 15), 12)  # Gold coin circle

        elif ctype == "health":
            self.image.fill((0, 0, 0, 0))  # Transparent background
            pygame.draw.rect(self.image, (0, 255, 0), (8, 5, 14, 20))  # Green rectangle for health
            # White cross on health pack
            pygame.draw.line(self.image, (255, 255, 255), (15, 10), (15, 20), 3)  # vertical
            pygame.draw.line(self.image, (255, 255, 255), (10, 15), (20, 15), 3)  # horizontal

        elif ctype == "life":
            self.image.fill((0, 0, 0, 0))  # Transparent background
            # Blue triangle for extra life
            pygame.draw.polygon(self.image, (0, 0, 255), [(15, 5), (25, 25), (5, 25)])

        else:
            self.image.fill((255, 255, 255))  # Default white block for unknown types

        self.rect = self.image.get_rect()
        self.rect.midbottom = (x, y)