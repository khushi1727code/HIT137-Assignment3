import random
from enemy import Enemy
from boss import BossEnemy
from collectible import Collectible

SCREEN_WIDTH = 800
GROUND_LEVEL = 540  # Adjust according to your player height

class Level:
    def __init__(self, level_number):
        self.level_number = level_number
        self.enemies = []
        self.collectibles = []

        if level_number == 1:
            self.create_enemies(3)
            self.create_collectibles(["coin", "health"])

        elif level_number == 2:
            self.create_enemies(5)
            self.create_collectibles(["coin", "coin", "health", "life"])

        elif level_number == 3:
            self.create_boss()
            self.create_collectibles(["coin", "health", "life"])

    def create_enemies(self, count):
        for _ in range(count):
            x = random.randint(100, SCREEN_WIDTH - 100)
            enemy = Enemy(x, GROUND_LEVEL)
            self.enemies.append(enemy)

    def create_boss(self):
        boss = BossEnemy(400, GROUND_LEVEL)
        self.enemies.append(boss)

    def create_collectibles(self, types):
        for ctype in types:
            x = random.randint(100, SCREEN_WIDTH - 100)
            collectible = Collectible(x, GROUND_LEVEL, ctype)
            self.collectibles.append(collectible)