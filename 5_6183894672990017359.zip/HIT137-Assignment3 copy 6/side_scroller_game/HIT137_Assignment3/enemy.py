import pygame

LEFT_WALL = 0
RIGHT_WALL = 800  # screen width

class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y, is_boss=False):
        super().__init__()
        self.is_boss = is_boss
        self.image = pygame.Surface((50, 50))
        self.image.fill((255, 0, 0) if not is_boss else (255, 165, 0))
        self.rect = self.image.get_rect(topleft=(x, y))
        
        self.health = 100 if not is_boss else 300
        self.max_health = self.health
        
        self.speed = 2 if not is_boss else 1
        self.direction = 1  # 1 = right, -1 = left
        
        self.velocity_y = 0
        self.on_ground = True
    
    def update(self):
        # Move enemy horizontally
        self.rect.x += self.speed * self.direction
        
        # Wall collision - reverse direction if hitting wall
        if self.rect.left < LEFT_WALL:
            self.rect.left = LEFT_WALL
            self.direction *= -1
        if self.rect.right > RIGHT_WALL:
            self.rect.right = RIGHT_WALL
            self.direction *= -1
        
        # Apply gravity
        self.velocity_y += 1
        self.rect.y += self.velocity_y
        
        # Ground collision (assuming ground at y=600 - height of enemy)
        ground_level = 600
        if self.rect.bottom >= ground_level:
            self.rect.bottom = ground_level
            self.velocity_y = 0
            self.on_ground = True
        else:
            self.on_ground = False
    
    def take_damage(self, amount):
        self.health -= amount