# config.py

# Screen settings
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

# Game settings
GROUND_HEIGHT = SCREEN_HEIGHT - 50  # Ground starts 50px from bottom
FPS = 60

# Player settings
PLAYER_SPEED = 5
JUMP_FORCE = 15
GRAVITY = 1

# Enemy settings
ENEMY_SPEED_RANGE = (-2, 2)

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
BLUE = (0, 0, 255)