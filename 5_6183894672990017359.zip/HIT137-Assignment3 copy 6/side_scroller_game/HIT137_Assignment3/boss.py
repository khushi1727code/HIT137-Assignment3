import pygame
import random
from enemy import Enemy
from projectile import Projectile

class BossEnemy(Enemy):
    def __init__(self, x, y):
        super().__init__(x, y)
        self.health = 300
        self.max_health = 300
        self.speed = 2
        self.direction = random.choice([-1, 1])
        self.last_shot_time = pygame.time.get_ticks()
        self.last_minion_time = pygame.time.get_ticks()
        self.shot_interval = 1500  # milliseconds
        self.minion_interval = 3000  # milliseconds
        self.hit_flash_duration = 150  # milliseconds
        self.last_hit_time = 0
        self.color = (255, 0, 255)

    def update(self):
        self.rect.x += self.speed * self.direction

        # Bounce on wall collision
        if self.rect.left < 0 or self.rect.right > 800:
            self.direction *= -1

    def shoot(self):
        current_time = pygame.time.get_ticks()
        if current_time - self.last_shot_time >= self.shot_interval:
            self.last_shot_time = current_time
            return Projectile(self.rect.centerx, self.rect.bottom, -1, color=(255, 0, 0))  # downward shot
        return None

    def spawn_minion(self):
        current_time = pygame.time.get_ticks()
        if current_time - self.last_minion_time >= self.minion_interval:
            self.last_minion_time = current_time
            return Enemy(self.rect.centerx, self.rect.bottom)
        return None

    def take_damage(self, amount):
        self.health -= amount
        self.last_hit_time = pygame.time.get_ticks()

    def draw(self, surface):
        # Flash red briefly when hit
        current_time = pygame.time.get_ticks()
        if current_time - self.last_hit_time < self.hit_flash_duration:
            flash_color = (255, 0, 0)
        else:
            flash_color = self.color
        pygame.draw.rect(surface, flash_color, self.rect)