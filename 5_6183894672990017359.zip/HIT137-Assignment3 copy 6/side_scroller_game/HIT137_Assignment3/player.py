import pygame

LEFT_WALL = 0
RIGHT_WALL = 800  # screen width

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((50, 60))
        self.image.fill((0, 128, 255))
        self.rect = self.image.get_rect(topleft=(x, y))
        
        self.velocity_x = 0
        self.velocity_y = 0
        self.speed = 5
        self.jump_strength = 15
        self.on_ground = False
        
        self.health = 100
        self.max_health = 100
        self.lives = 3
        
    def update(self, keys):
        self.velocity_x = 0
        if keys[pygame.K_LEFT]:
            self.velocity_x = -self.speed
        if keys[pygame.K_RIGHT]:
            self.velocity_x = self.speed
        
        # Apply horizontal movement
        self.rect.x += self.velocity_x
        
        # Wall collision check - keep player inside screen
        if self.rect.left < LEFT_WALL:
            self.rect.left = LEFT_WALL
        if self.rect.right > RIGHT_WALL:
            self.rect.right = RIGHT_WALL
        
        # Apply gravity
        self.velocity_y += 1  # gravity acceleration
        self.rect.y += self.velocity_y
        
        # Ground collision check
        if self.rect.bottom >= 600:  # Assuming screen height = 600
            self.rect.bottom = 600
            self.velocity_y = 0
            self.on_ground = True
        else:
            self.on_ground = False
    
    def jump(self):
        if self.on_ground:
            self.velocity_y = -self.jump_strength