import pygame

class Projectile(pygame.sprite.Sprite):
    SPEED = 10

    def __init__(self, x, y, direction=1, color=(0, 255, 255)):  # Added color parameter
        super().__init__()
        self.image = pygame.Surface((10, 5))
        self.image.fill(color)  # Use provided color
        self.rect = self.image.get_rect(center=(x, y))
        self.direction = direction

    def update(self):
        self.rect.x += self.SPEED * self.direction

        # Remove if off screen
        if self.rect.right < 0 or self.rect.left > 800:
            self.kill()